# 运行指南
## 解压到Liner文件夹到纯英文路径下面（建议）
## 安装Python3.9
## 执行 Dependency_package.bat 安装依赖库 
## 执行 start.bat启动分析
## 后续使用只要拖入xlxs文件到py同级文件夹，更名为main.xlsx，或者在已有的模板里面继续完善即可