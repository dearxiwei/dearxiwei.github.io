![](https://img.shields.io/badge/license-MIT-green)  ![](https://img.shields.io/badge/version-1.50-red)

## quarkHomePage
H5仿夸克浏览器主页
![](https://ae01.alicdn.com/kf/H244bb0ca385f4109a1c9d11d4a8be564O.jpg)
# 更新计划
1. 搜索历史
2. 壁纸库
3. 夜间模式
4. 可以添加预设书签
# 图标来源
* Pure轻雨图标包
# 在线地址
[https://liumingye.gitee.io/quarkhomepage/](https://liumingye.gitee.io/quarkhomepage/)
# 感谢开源项目
* jquery
* sortablejs
* Swiper
* TouchSwipe
* requirejs
